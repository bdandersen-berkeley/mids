params <-
list(report_date = "2019-04-03", read_name_start = "crime_v2", 
    title = "w203 Lab 3: Reducing Crime")

## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

library(tidyverse)

report_date <- params$report_date
read_name_start <- params$read_name_start




## ------------------------------------------------------------------------
test <- read_file("README.md")

