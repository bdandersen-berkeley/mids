## W203 Statistics for Data Science

### Spring 2019

### Instructors
Eric Penner: eric.penner@ischool.berkeley.edu

Paul Laskowski: paul@ischool.berkeley.edu

Gunnar Kleeman: gunnarklee@ischool.berkeley.edu

Casper Joergensen: cjoergensen@ischool.berkeley.edu

### TA's

Gurdit Chahal: g.s.chahal@berkeley.edu

Chi long Ansjory: ansjory@berkeley.edu

Todd Young: todd.young@ischool.berkeley.edu

### Sections

Section 1: Eric Penner   M    4:00 PM -   5:30 PM
<a href="https://calendar.google.com/calendar?cid=YmVya2VsZXkuZWR1X25lcG1wYTE5bTJuZTg3dDhzcnRrajQ0cjJnQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20">Section 1 Google Calendar</a>

Section 2: Eric Penner   M    6:30 PM  -  8:00 PM
<a href="https://calendar.google.comcalendar?cid=YmVya2VsZXkuZWR1X3RkYnVtMGJnb3M5ODJzaWk2dHBjbmVvdnFzQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20">Section 2 Google Calendar</a>

Section 3: Eric Penner   Sat    10:00 AM  -  11:30 AM
<a href="https://calendar.google.com/calendar?cid=YmVya2VsZXkuZWR1XzQ5YnY2bzFjcmdpcGpyb3RsNTZyMG1paGlnQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20">Section 3 Google Calendar</a>

Section 4: Paul Laskowski & Gunnar Kleeman    W    4:00 PM  -  5:30 PM
<a href="https://calendar.google.com/calendar?cid=YmVya2VsZXkuZWR1X25rdWlkdWozc205YmJoZ21xdTk2cHZkYm1zQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20">Section 4 Google Calendar</a>

Section 5: Casper Joergensen         W    6:30 PM  -  8:00 PM
<a href="https://calendar.google.com/calendar?cid=YmVya2VsZXkuZWR1XzhtOTE3b3E4c3A3azgxbDN1b3AwdmYza3ZzQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20">Section 5 Google Calendar</a>

Section 6: Paul Laskowski          M    4:00 PM  -  5:30 PM
<a href="https://calendar.google.com/calendar?cid=YmVya2VsZXkuZWR1X2J0bmtxdjlqZjNqMGRxM203bXFzcnE4NnM4QGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20">Section 6 Google Calendar</a>

Section 7: Casper Joergensen       W    4:00 PM  - 6:30 PM
<a href="https://calendar.google.com/calendar?cid=YmVya2VsZXkuZWR1X2M3bHFjZDI5bGttYTJ1dG12dGczam1ocnUwQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20">Section 7 Google Calendar</a>

### Sites
There are 3 places that you will routinely access in order to complete this course.

<a href="https://github.com/w203-spring-19">GitHub</a>: This is where **all** course documents will be distributed to you. Throughout the course of the semester we will release (grant you access to specific private repositories) live session documents, homeworks, labs, datasets, and really anything else. It is your responsibility to clone, manage, and keep up to date the repos that you are given access to. We recommend that as soon as you are given access to a repo you clone that repo onto your machine and then immediately start a working branch of that repo so that any updates that we may later push will not cause any merge conflicts.

<a href="https://piazza.com/class/jqlgwy1eerl2rt">Piazza Forum</a>: This is where **all** communications between students and instructors will take place for this course. You can post questions, messages and the like to the  whole class, other student or the instructors as yourself or anonymously. We encourage you to ask and answer question posed to the entire class those who do will be rewarded for it!


<a href="https://learn.datascience.berkeley.edu/login">ISVC</a>: This is where you will watch async video, turn in assignments, take quizzes, and get your grades. There are number of important requirement regarding the manner in which you will need to turn in assignments, some with penalties for non compliance it is your responsibility to know and act in accordance with these any question should be posted to piazza asap.

### Weekly Outline

|Video Units   |Mon   |Tues  |Wed   |Sat   |Abbreviated Title                       |Work Assigned       |Work Due            |
|--------------|------|------|------|------|----------------------------------------|--------------------|--------------------|
|1             |7-Jan |8-Jan |9-Jan |12-Jan|Intro to Quant Research and Descr. Stats|unit_1_hw           |                    |
|3, 2.4 and 2.5|14-Jan|15-Jan|16-Jan|19-Jan|Research Design and Prob. Theory        |unit_3_hw           |unit_1_hw           |
|4.1-4.9       |21-Jan|22-Jan|23-Jan|26-Jan|Discrete Random Variables               |unit_4_part_1_hw    |unit_3_hw           |
|4.10-4.16     |28-Jan|29-Jan|30-Jan|2-Feb |Continuous Random Variables             |unit_4_part_2_hw    |unit_4_part_1_hw    |
|5             |4-Feb |5-Feb |6-Feb |9-Feb |Joint Distributions                     |Lab_1               |unit_4_part_2_hw    |
|6             |11-Feb|12-Feb|13-Feb|16-Feb|Sampling and the CLT                    |unit_6_hw           |                    |
|7             |18-Feb|19-Feb|20-Feb|23-Feb|Estimators                              |unit_7_hw           |Lab_1, unit_6_hw    |
|8             |25-Feb|26-Feb|27-Feb|2-Mar |Hypothesis Testing                      |unit_8_hw, quiz_1   |unit_7_hw           |
|9             |4-Mar |5-Mar |6-Mar |9-Mar |Comparing 2 Means and Reproducibility   |Lab_2               |unit_8_hw, quiz_1   |
|10            |11-Mar|12-Mar|13-Mar|16-Mar|Bivariate OLS Estimation                |unit_10_hw          |                    |
|11            |18-Mar|19-Mar|20-Mar|23-Mar|Multivariate OLS and Omitted Variables  |Lab_3_part_1        |Lab_2, unit_10_hw   |
|              |25-Mar|26-Mar|27-Mar|30-Mar|Spring Break - No Class                 |                    |                    |
|12            |1-Apr |2-Apr |3-Apr |6-Apr |OLS Inference                           |Lab_3_part_2        |Lab_3_part_1        |
|13            |8-Apr |9-Apr |10-Apr|13-Apr|Linear Model Specification              |Lab_3_part_3, quiz_2|Lab_3_part_2        |
|14            |15-Apr|16-Apr|17-Apr|      |Experiments                             |                    |Lab_3_part_3, quiz_2|


### Description
The goal of this course is to provide students with a foundational understanding of classical statistics and how it fits within the broader context of data science.  Students will learn to apply the most common statistical procedures correctly, checking assumptions and responding appropriately when they appear violated.  Emphasis is placed on different practices that constitute an effective analysis, including formulating research questions, operationalizing variables, exploring data, selecting hypothesis tests, and communicating results.

The course begins with an introduction to probability theory, with pencil-and-paper problem sets to develop intuition for the key concepts that underlie statistical models.  Next, we use the simple example of the mean to demonstrate the use of estimators and hypothesis tests.  We then turn to classical linear regression, taking several weeks to build a strong understanding of this central topic.  Our treatment stresses causal inference and includes a discussion of omitted variables.  At the end, we describe some of the concerns that arise in the process of specifying linear models.  Throughout the course, students will practice analyzing real-world data using the open-source language, R.   (3 units)

### Prerequisites

*  Working knowledge of calculus. A good understanding of linear algebra is strongly recommended, as the course will make occasional use of matrix notation.

* At least one prior college-level statistics course is recommended.

### Weekly Workflow

**Before live session**: Students watch the asynchronous videos and study the assigned readings for a given unit.  Note that the readings are mandatory and often include more examples than provided in the videos.  Students should also complete any assigned pre-class exercises.

**During live session**: Students engage in activities to reinforce and extend the materials they studied.

**After live session**: Students complete the homework, lab, or other assignments corresponding to the given unit.  Homeworks will be due 24 hours before the following live session.  See individual labs for their due dates.

### Required Textbooks:

* Devore, J. L. (2015). Probability and statistics for engineering and the sciences Boston, MA: Cengage Learning.



* Wooldridge, J. (2015). Introductory econometrics: A modern approach 6th ed. Boston, MA: Cengage Learning.

### Recommended Textbooks:

* Fox, J., \& Weisberg, S. (2011). An R companion to applied regression. Thousand Oaks, CA: Sage Publications.



### Policies and Important Dates

#### Grading:

* Probability Theory Lab (individual lab) - 20%
* Comparing Means Lab (group lab) - 20%
* Linear Regression Lab (group lab) - 25%
* 2 Quizzes - 10% (5% each)
* Weekly Homework - 15%
* Class Participation - 10%

#### Labs

In a typical lab, students will download a real-world dataset to analyze using the techniques learned in class.  Each student **must** submit (1) a PDF report detailing the solutions and (2) an R-script, Jupyter notebook, or Rmd file that is used to generate the solutions. Failing to submitting one of these files will result in an automatic 20% grade reduction.

The Probability Theory lab is unique in that it requires a large number of pencil-and-paper calculations.  Students may scan in their work for submission or use LaTex to type their solutions.  This is an individual lab.

Lab 2 and Lab 3 are designed to be group labs.  Students will work in teams of two or three to complete these.

The Linear Regression Lab gives students a chance to synthesize knowledge gained throughout the semester and combine technical, inferential, and strategic thinking to produce a professional-level analysis.  In the course of this assignment, student teams will have a chance to provide peer feedback to each other.  This will be a chance to practice critical reading of statistical analysis, and enable the strongest possible final products.


#### Quizzes:
The purpose of the quizzes is to test your ability to reason about the concepts covered in the course.  Quizzes will be conducted under a time limit and may include multiple-choice questions, short-answer questions, and other question types.


#### Weekly Homework:
Most weeks of the course include a homework set that is designed to reinforce and extend the concepts covered in class.  Each homework is due 24 hours before the following live session so that instructors have time to assess student progress.  Homework will only be given a grade of 0, 1, 2, or 3.  In general, students will not receive individual feedback on homework.  Instead, it is their responsibility to bring any questions they have to office hours.


#### Office Hours:
Office hours are a central component of this course, giving instructors the chance to tailor explanations to individual students.  Students may attend the office hours of any instructor, and they are encouraged to attend as many office hours as possible.

#### Participation:
Students are expected to be active participants in class activities and to come to the live sessions prepared to discuss the videos and readings.  Students should also come to class with questions that they would like to discuss with classmates and the instructor.  Most importantly, we expect all students to behave professionally and help create a supportive learning environment.

#### Late Policy:
Homework and labs submitted after the deadline will be docked an automatic 20%.  Unfortunately, we are not able to accept any work after the live session in which we discuss the solutions.


### Course Outline





**Introduction and Descriptive Statistics (2 lectures)**
  The course begins with an introduction to quantitative research and tools for describing a sample of data.

* Measurement
* Types of variables
* Operationalization of constructs
* Descriptive statistics
* Measures of location
* Measures of dispersion

**Probability Theory and Mathematical Statistics (5 lectures)**
  We build up from mathematical foundations to understand how statistical models behave.    

* Axioms of probability
* Random variables
* Probability density and cumulative probability functions
* Joint distributions
* Unconditional and conditional expectation
* Variance and covariance
* Sampling
* The Central Limit Theorem


**Estimation and Hypothesis Testing (3 lectures)**
  We introduce statistical inference - the process by which we use a sample to learn things about a population model.

* Desirable properties of estimators
* Maximum likelihood estimators
* Method of moments estimators
* Confidence intervals
* The Frequentist approach to statistical inference
* Z-tests and t-tests for one sample
* Parametric tests for comparing means
* The reproducibility crisis
* p-hacking
* p-value corrections
* Publication bias
* Strategies for improving reproducibility

**Classical Linear Regression (5 Lectures)**  
  We study linear regression with an emphasis on correctly checking assumptions, and on the flexibility inherent in the linear model.


* Bivariate estimation
* Multivariate estimation
* Rubin's Causal Model
* Omitted variable bias
* Factors that influence standard errors
* The classical linear model assumptions
* Key assumptions for large sample sizes
* The use of variable transformations, polynomials, indicator variables, and interaction terms
* Regression Diagnostics and formal statistical assumption testing
* True experiments
