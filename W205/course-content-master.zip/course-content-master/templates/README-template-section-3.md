## Part 3 - Streaming

