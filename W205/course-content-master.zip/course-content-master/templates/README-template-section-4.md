## Part 4 - Putting it All Together

