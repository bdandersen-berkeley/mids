## Part 2 - The Basics

