# Assignment 06 - bdandersen-berkeley-history.txt Annotations

**Brad Andersen**

**W205 - Summer 2019 - Doris Schioberg**

## Preparatory Work

Once in my GCP MIDS VM instance, changing directories to *course-content*, and updating the Git repository.

```
  356  cd course-content
  357  git pull origin master
  358  cd ..
```
## MIDS, Kafka and Zookeeper Docker Container Definitions

Work is to be performed beneath the *kafka* directory, created beneath the *w205* directory in my home directory.  The *docker-compose.yml* YAML file is to be copied from the assignment's directory within the *course-content* Git repository.  However, I mistype the pathname, and must execute the copy command again with the correct path.

Descending into the *kafka* directory, I examine *docker-compose.yml* using `vi`.

```
  359  mkdir kafka
  360  cp ./git-repos/course-content/06-Transforming-Data/docker-compose.yml ./kafka
  361  cp ./course-content/06-Transforming-Data/docker-compose.yml ./kafka
  362  cd kafka
  363  vi docker-compose.yml
```
  
## Bringing Docker Online

I bring Docker online as a background process, and check to see that the containers defined within the *docker-compose.yml* file have started without error.
  
```
  364  docker-compose up -d
  365  docker-compose ps
```

## Retrieval of the JSON Data File

I retrieve the JSON-formatted data file from the documented location using the `curl` utility, copying it into the current (i.e. *kafka*) directory.

```
  366  curl -L -o assessment-attempts-20180128-121051-nested.json https://goo.gl/ME6hjp
```

## Creation of the Kafka Topic to Which to Direct Messaging

Using `docker-compose`, I invoke Kafka in the *kafka* Docker container, and create a new topic named *assignment06*.  Only a single partition for the topic is created, and the `zookeeper` instance (listening on port 32181) is identified for managing Kafka synchronization should we wish to operate in a distributed environment (which we're not).

```
  367  docker-compose exec kafka kafka-topics --create --topic assignment06 --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
```

## Examining the JSON Data File

I investigate the contents of the JSON data file using `head`, and then direct the contents of the file (formatted using `jq`) to another file for easier viewing.  I check to ensure that the formatted JSON file looks acceptable.

```
  368  ls
  369  head assessment-attempts-20180128-121051-nested.json 
  370  docker-compose exec mids bash -c "cat /w205/kafka/assessment-attempts-20180128-121051-nested.json | jq '.' > formatted-json.json
"
  371  ls
  372  cd 
  373  ls
  374  cd w205
  375  ls
  376  vi formatted-json.json 
```

## Streaming Data to the Kafka *assignment06* Topic

I invoke a command-line operation leveraging the `bash` shell of the `mids` Docker container to direct content of the JSON data file to the *assignment06* Kafka topic.  The command line operation leverages pipes, with output from the prior command being directed (i.e. piped) to the current command as follows:

* The JSON data file is directed to an output destination
* Output is directed to the `jq` utility, formatting the data to an easier understood representation
* Formatted JSON is serialized to the Kafka *assignment06* topic
* Once all operations are complete, the message 'Done producing messages' is directed to the current console.

```
  377  cd kafka
  378  docker-compose exec mids bash -c "cat /w205/kafka/assessment-attempts-20180128-121051-nested.json | jq '.[]' -c | kafkacat -P -b kafka:29092 -t assignment06 && echo 'Done producing messages'"
```

## Retrieval of Messages

I consume messages (i.e. formatted JSON data) from the Kafka *assignment06* topic, and serialize the first ten (`--max-messages 10`) to the current console.  I then check to see how many distinct messages had been serialized *to* the *assignment06* topic, finding 3,281.

```
  379  docker-compose exec kafka kafka-console-consumer --bootstrap-server localhost:29092 --topic assignment06 --from-beginning --max-messages 10
  380  docker-compose exec mids bash -c "kafkacat -C -b kafka:29092 -t assignment06 -o beginning -e" | wc -l
```

## Cleanup

I shut down the Docker containers, check to ensure that the containers are no longer running, and then direct my command line history to *bdandersen-history.txt*.

```  
  381  docker-compose down
  382  docker-compose -ps
  383  docker ps
  384  ls
  385  history > bdandersen-history.txt
```
