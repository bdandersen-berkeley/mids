# Assignment 09 - README.md

**Brad Andersen**

**W205 - Summer 2019 - Doris Schioberg**

## Assignment Summary

Using applications executing within several Docker containers and hosted on a Google Cloud virtual machine, a simple web application was written, deployed and tested.  Goals of the web application included:
* Develop a web application written in Python and founded upon the Flask web framework
* Receive HTTP GET requests using various URL endpoints
* Acknowledge receipt by sending a text message to the calling client in an HTTP response
* Log events received to Kafka

## *docker-compose.yml*

```
---
version: '2'
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    environment:
      ZOOKEEPER_CLIENT_PORT: 32181
      ZOOKEEPER_TICK_TIME: 2000
    expose:
      - "2181"
      - "2888"
      - "32181"
      - "3888"

  kafka:
    image: confluentinc/cp-kafka:latest
    depends_on:
      - zookeeper
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:32181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    expose:
      - "9092"
      - "29092"

  mids:
    image: midsw205/base:0.1.8
    stdin_open: true
    tty: true
    expose:
      - "5000"
    ports:
      - "5000:5000"
    volumes:
      - ~/w205:/w205
```

## *basic_game_api.py*
```
#!/usr/bin/env python
  
from kafka import KafkaProducer
from flask import Flask
app = Flask(__name__)
event_logger = KafkaProducer(bootstrap_servers = "kafka:29092")
events_topic = "events"

@app.route("/")
def default_response():
    event_logger.send(events_topic, "default".encode())
    return "This is the default response!"

@app.route("/purchase_a_sword")
def purchase_sword():
    # TODO: Business logic associated with sword purchase
    event_logger.send(events_topic, "purchased_sword".encode())
    return "Sword Purchased!"
```

## Procedural Steps

### Docker Container Setup and Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~$ cd w205
bdandersen@bdandersen-mids-w205:~/w205$ mkdir flask-with-kafka
bdandersen@bdandersen-mids-w205:~/w205$ mv docker-compose.yml flask-with-kafka/
bdandersen@bdandersen-mids-w205:~/w205$ cd flask-with-kafka/
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka$ cp ../course-content/09-Ingesting-Data/docker-compose.yml .
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka$ docker-compose up -d
```
#### Console Output
```
Creating network "flaskwithkafka_default" with the default driver
Creating flaskwithkafka_zookeeper_1 ... 
Creating flaskwithkafka_mids_1 ... 
Creating flaskwithkafka_mids_1
Creating flaskwithkafka_zookeeper_1 ... done
Creating flaskwithkafka_kafka_1 ... 
Creating flaskwithkafka_kafka_1 ... done
```
#### Explanation
A directory in which to maintain assignment files -- `flask-with-kafka` -- was created beneath the `w205` directory in my user's home directory.  A docker-compose YAML file was copied from the local ``course-content`` Git repository, and Docker containers were brought online using docker-compose invoked as a background process.

### Kafka Topic Creation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka$ docker-compose exec kafka kafka-topics --create --topic events --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
```
#### Console Output
```
Created topic "events".
```
#### Explanation
Kafka (running in a separate Docker container) was executed and a new Kafka topic -- `events` -- was created to which to stream web application logging messages.

### Web Application Development and Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka$ vi basic_game_api.py
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka$ docker-compose exec mids env FLASK_APP=/w205/flask-kafka/basic_game_api.py flask run
```
#### Output
```
* Serving Flask app "basic_game_api"
* Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
 ```
#### Explanation
The Python web application -- detailed above in *basic_game_api.py* -- was written.  Conforming to the Flask web framework's conventions, two endpoints (i.e. "routes") were defined using Flask's function decorator `@app.route()`:
* `@app.route("/")` -- Receiving HTTP requests beneath the application's base URL
* `@app.route("/purchase_a_sword")` -- Receiving HTTP requests beneath the application's `/purchase_a_sword` URL

Both endpoints log HTTP requests received to Kafka, and return a text message in an HTTP response.
The Flask framework (within the separate `mids` Docker container) was executed, and *basic_game_api.py* was identified as the script to which to direct events.  The Flask server began executing, and acknowledged invocation with messages that included the URL beneath which the application is running:
* `http://127.0.0.1` identifies the local host's IP address
* `:5000` identifies the port number upon which the Flask server is listening

### Web Application Test Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka$ docker-compose exec mids curl http://localhost:5000/
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka$ docker-compose exec mids curl http://localhost:5000/purchase_a_sword
```
#### Output (Client Terminal)
```
This is the default response!
Sword Purchased!
```
#### Output (Server Terminal)
``` 
127.0.0.1 - - [12/Jul/2019 18:19:03] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [12/Jul/2019 18:19:19] "GET /purchase_a_sword HTTP/1.1" 200 -
```
#### Explanation
From a separate client terminal (on the same virtual machine as the Flask server), two HTTP GET requests were sent (using curl, the command-line HTTP client) to the Flask server, identifying the two endpoints defined within *basic_game_api.py*.  HTTP responses were received, and the textual payload in each matched those defined within the Python script.
In the terminal in which the Flask server is executing, Flask acknowledged the receipt of the HTTP requests by logging each event to the console.  Information logged includes:
* Server's IP address
* Timestamp of receipt of HTTP request
* HTTP request (identifying the HTTP method, the endpoint, the version of the HTTP protocol used, and the HTTP response status code 200 indicating success)

### Check of Kafka Topic
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka$ docker-compose exec mids bash -c "kafkacat -C -b kafka:29092 -t events -o beginning -e"
```
#### Output
```
default
purchased_sword
```
#### Explanation
The `kafkacat` command was executed (running in a separate Docker container) to direct events logged in the `events` topic to the terminal.  The two messages associated with the HTTP GET requests sent to endpoints defined in *basic_game_api.py* were correctly logged.

### Flask Server and Docker Container Halt
#### Commands Executed
```
^C
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka$ docker-compose down
```
#### Output
```
Stopping flaskwithkafka_kafka_1     ... done
Stopping flaskwithkafka_zookeeper_1 ... done
Stopping flaskwithkafka_mids_1      ... done
Removing flaskwithkafka_kafka_1     ... done
Removing flaskwithkafka_zookeeper_1 ... done
Removing flaskwithkafka_mids_1      ... done
Removing network flaskwithkafka_default
```
#### Explanation
The Flask server was stopped by typing a Control-C to the terminal.  The Docker containers were then shut down, and messages acknowledging their being stopped and the Flask server's HTTP endoint removed were directed to the console.

