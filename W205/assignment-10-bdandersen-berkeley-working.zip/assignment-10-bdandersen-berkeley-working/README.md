# Assignment 10 - README.md

**Brad Andersen**

**W205 - Summer 2019 - Doris Schioberg**

## Assignment Summary

Using applications executing within several Docker containers and hosted on a Google Cloud virtual machine, a simple web application was written, deployed and tested.  Goals of the web application included:
* Develop a web application written in Python and founded upon the Flask web framework
* Receive HTTP GET requests using various URL endpoints
* Acknowledge receipt by sending a text message to the calling client in an HTTP response
* Log events received to Kafka as JSON objects to the `events` topic, including a handful of HTTP request headers
* Retrieve data from the Kafka `events` topic using Spark's PySpark command line.  Convert events represented in binary format to strings, direct the string representations to a `DataFrame`, and print the contents of the `DataFrame` to the PySpark console.

## *docker-compose.yml*

```
--
version: '2'
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    environment:
      ZOOKEEPER_CLIENT_PORT: 32181
      ZOOKEEPER_TICK_TIME: 2000
    expose:
      - "2181"
      - "2888"
      - "32181"
      - "3888"
    extra_hosts:
      - "moby:127.0.0.1"

  kafka:
    image: confluentinc/cp-kafka:latest
    depends_on:
      - zookeeper
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:32181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    expose:
      - "9092"
      - "29092"
    extra_hosts:
      - "moby:127.0.0.1"

  spark:
    image: midsw205/spark-python:0.0.5
    stdin_open: true
    tty: true
    volumes:
      - ~/w205:/w205
    expose:
      - "8888"
    ports:
      - "8888:8888"
    extra_hosts:
      - "moby:127.0.0.1"
    command: bash

  mids:
    image: midsw205/base:0.1.8
    stdin_open: true
    tty: true
    expose:
      - "5000"
    ports:
      - "5000:5000"
    volumes:
      - ~/w205:/w205
    extra_hosts:
      - "moby:127.0.0.1"
```

## *game_api_10.py*
```
#!/usr/bin/env python
  
import json
from kafka import KafkaProducer
from flask import Flask, request

app = Flask(__name__)
KAFKA_EVENT_LOGGER = KafkaProducer(bootstrap_servers = "kafka:29092")
KAFKA_EVENT_TOPIC = "events"

def log_to_kafka(topic, event):
    event.update(request.headers)
    KAFKA_EVENT_LOGGER.send(topic, json.dumps(event).encode())

@app.route("/")
def default_response():
    default_event = {"event_type": "default"}
    log_to_kafka(KAFKA_EVENT_TOPIC, default_event)
    return "This is the default response!\n"

@app.route("/purchase_a_sword")
def purchase_sword():
    purchase_sword_event = {"event_type": "purchase_sword"}
    log_to_kafka(KAFKA_EVENT_TOPIC, purchase_sword_event)
    return "Sword Purchased!\n"
```

## Procedural Steps

### Docker Container Setup and Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~$ cd w205
bdandersen@bdandersen-mids-w205:~/w205$ mkdir flask-with-kafka-and-spark
bdandersen@bdandersen-mids-w205:~/w205$ cd flask-with-kafka-and-spark/
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ cp ../course-content/10-Transforming-Streaming-Data/docker-compose.yml .
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose up -d
```
#### Console Output
```
Creating network "flaskwithkafkaandspark_default" with the default driver
Creating flaskwithkafkaandspark_spark_1 ... 
Creating flaskwithkafkaandspark_mids_1 ... 
Creating flaskwithkafkaandspark_zookeeper_1 ... 
Creating flaskwithkafkaandspark_spark_1
Creating flaskwithkafkaandspark_zookeeper_1
Creating flaskwithkafkaandspark_zookeeper_1 ... done
Creating flaskwithkafkaandspark_kafka_1 ... 
Creating flaskwithkafkaandspark_kafka_1 ... done
```
#### Explanation
A directory in which to maintain assignment files -- `flask-with-kafka-and-spark` -- was created beneath the `w205` directory in my user's home directory.  A docker-compose YAML file was copied from the local ``course-content`` Git repository, and Docker containers were brought online using docker-compose invoked as a background process.

This week's assignment includes an additional container hosting Spark.

### Kafka Topic Creation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec kafka kafka-topics --create --topic events --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
```
#### Console Output
```
Created topic "events".
```
#### Explanation
Kafka (running in a separate Docker container) was executed and a new Kafka topic -- `events` -- was created to which to stream web application logging messages.

### Web Application Development and Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ vi game_api_10.py
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids env FLASK_APP=/w205/flask-kafka/game_api_10.py flask run
```
#### Output
```
* Serving Flask app "game_api_10"
* Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
 ```
#### Explanation
The Python web application -- detailed above in *game_api_10.py* -- was written.  Conforming to the Flask web framework's conventions, two endpoints (i.e. "routes") were defined using Flask's function decorator `@app.route()`:
* `@app.route("/")` -- Receiving HTTP requests beneath the application's base URL
* `@app.route("/purchase_a_sword")` -- Receiving HTTP requests beneath the application's `/purchase_a_sword` URL
The application was modified from the prior week's Python script by consolidating common Kafka logging functionality in the *`log_to_kafka()`* function.

Both endpoints log HTTP requests received to Kafka, and return a text message in an HTTP response.
The Flask framework (within the separate `mids` Docker container) was executed, and *game_api_10.py* was identified as the script to which to direct events.  The Flask server began executing, and acknowledged invocation with messages that included the URL beneath which the application is running:
* `http://127.0.0.1` identifies the local host's IP address
* `:5000` identifies the port number upon which the Flask server is listening

### Web Application Test Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids curl http://localhost:5000/
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids curl http://localhost:5000/
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids curl http://localhost:5000/
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids curl http://localhost:5000/purchase_a_sword
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids curl http://localhost:5000/purchase_a_sword
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids curl http://localhost:5000/purchase_a_sword
```
#### Output (Client Terminal)
```
This is the default response!
This is the default response!
This is the default response!
Sword Purchased!
Sword Purchased!
Sword Purchased!
```
#### Output (Server Terminal)
``` 
127.0.0.1 - - [18/Jul/2019 18:12:40] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [18/Jul/2019 18:12:43] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [18/Jul/2019 18:12:46] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [18/Jul/2019 18:12:54] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [18/Jul/2019 18:12:58] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [18/Jul/2019 18:13:02] "GET /purchase_a_sword HTTP/1.1" 200 -
```
#### Explanation
From a separate client terminal (on the same virtual machine as the Flask server), six HTTP GET requests were sent (using *`curl`*, the command-line HTTP client) to the Flask server, identifying the two endpoints defined within *game_api_10.py*.  HTTP responses were received, and the textual payload in each matched those defined within the Python script.

Six requests were sent in order to ensure that events were reaching and being logged by Kafka appropriately.

In the terminal in which the Flask server is executing, Flask acknowledged the receipt of the HTTP requests by logging each event to the console.  Information logged includes:
* Server's IP address
* Timestamp of receipt of HTTP request
* HTTP request (identifying the HTTP method, the endpoint, the version of the HTTP protocol used, and the HTTP response status code 200 indicating success)

### Check of Kafka Topic
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids bash -c "kafkacat -C -b kafka:29092 -t events -o beginning -e"
```
#### Output
```
{"event_type": "default"}
{"event_type": "default"}
{"event_type": "default"}
{"event_type": "purchase_sword"}
{"event_type": "purchase_sword"}
{"event_type": "purchase_sword"}
% Reached end of topic events [0] at offset 8: exiting
```
#### Explanation
The `kafkacat` command was executed (running in a separate Docker container) to direct events logged in the `events` topic to the terminal.  The two messages associated with the HTTP GET requests sent to endpoints defined in *game_api_10.py* were correctly logged, formatted as JSON.

### Inclusion of HTTP Request Headers in Events
#### Commands Executed
```
^C
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ vi game_api_10.py
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids env FLASK_APP=/w205/flask-kafka/game_api_10.py flask run
```
#### Output
```
* Serving Flask app "game_api_10"
* Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
 ```
#### Explanation
The Flask application was halted, and *game_api_10.py* was updated to include HTTP headers in logged events.  The Flask web application container was restarted.

### Second Web Application Test Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids curl http://localhost:5000/
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids curl http://localhost:5000/purchase_a_sword
```
#### Output (Client Terminal)
```
This is the default response!
Sword Purchased!
```
#### Output (Server Terminal)
``` 
127.0.0.1 - - [18/Jul/2019 18:54:57] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [18/Jul/2019 18:55:06] "GET /purchase_a_sword HTTP/1.1" 200 -
```
#### Explanation
*`curl`* was used again to test that the endpoints defined in *game_api_10.py* are continuing to behave as expected.

### Second Check of Kafka Topic
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec mids bash -c "kafkacat -C -b kafka:29092 -t events -o beginning -e"
```
#### Output
```
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
% Reached end of topic events [0] at offset 2: exiting
```
#### Explanation
The `kafkacat` command was executed (running in a separate Docker container) to direct events logged in the `events` topic to the terminal.  The two messages associated with the HTTP GET requests sent to endpoints defined in *game_api_10.py* were correctly logged, formatted as JSON, and now include HTTP headers `Host`, `Accept`, and `User-Agent` as expected.

### Spark Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose exec spark pyspark
```
#### Output
```
Python 3.6.1 |Anaconda 4.4.0 (64-bit)| (default, May 11 2017, 13:09:58) 
[GCC 4.4.7 20120313 (Red Hat 4.4.7-1)] on linux
Type "help", "copyright", "credits" or "license" for more information.
Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel). For SparkR, use setLogLevel(newLevel).
19/07/18 20:03:18 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
19/07/18 20:03:28 WARN ObjectStore: Failed to get database global_temp, returning NoSuchObjectException
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /__ / .__/\_,_/_/ /_/\_\   version 2.2.0
      /_/

Using Python version 3.6.1 (default, May 11 2017 13:09:58)
SparkSession available as 'spark'.
```
#### Explanation
Spark was started in a separate Docker container, and the PySpark command line interface was begun.

### Streaming Kafka Events to Spark
#### Commands Executed At the PySpark Prompt
```
>>> raw_events = spark.read.format("kafka").option("kafka.bootstrap.servers", "kafka:29092").option("subscribe", "events").option("startingOffsets", "earliest").option("endingOffsets", "latest").load()
>>> raw_events.show()
>>> events = raw_events.select(raw_events.value.cast("string"))
>>> extracted_events = events.rdd.map(lambda x: json.loads(x.value)).toDF()
>>> extracted_events.show()
>>> quit()

```
#### Output
```
+----+--------------------+------+---------+------+--------------------+-------------+
| key|               value| topic|partition|offset|           timestamp|timestampType|
+----+--------------------+------+---------+------+--------------------+-------------+
|null|[7B 22 48 6F 73 7...|events|        0|     0|2019-07-18 18:54:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     1|2019-07-18 18:55:...|            0|
+----+--------------------+------+---------+------+--------------------+-------------+

19/07/18 21:00:27 WARN CachedKafkaConsumer: CachedKafkaConsumer is not running in UninterruptibleThread. It may hang when CachedKafkaConsumer's methods are interrupted because of KAFKA-1894
19/07/18 21:00:27 WARN CachedKafkaConsumer: CachedKafkaConsumer is not running in UninterruptibleThread. It may hang when CachedKafkaConsumer's methods are interrupted because of KAFKA-1894
+------+--------------+-----------+--------------+
|Accept|          Host| User-Agent|    event_type|
+------+--------------+-----------+--------------+
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
+------+--------------+-----------+--------------+
```
#### Explanation
Flask event data (originating in *game_api_10.py*) were streamed from Kafka, and were maintained as an object of type `pyspark.sql.dataframe.DataFrame`.  Contents of the `DataFrame` object were assigned to the variable `raw_events`, and the contents of the `DataFrame` were directed to the terminal.  Of note:
* Values (event data) are maintained as binary data
* Two entries exist representing the two *`curl`* calls invoking the *game_api_10.py* application, above.
Values maintained in the `raw_events` `DataFrame` are cast to strings, and assigned to the variable `events`.  Finally, the string value of each item in `events` is mapped to a second `DataFrame` object assigned to the variable `extracted_events`.  Invoking the *`show()`* method on `DataFrame` `extracted_events` directs each row to the console.  Columns in the `DataFrame` correspond to the key names of the dictionary logged to Kafka with the invocation of each HTTP request.  The first three columns represent the HTTP request headers, and the last column represents the string assigned to each event within *game_api_10.py*.

### Flask Server and Docker Container Halt
#### Commands Executed
```
^C
bdandersen@bdandersen-mids-w205:~/w205/flask-with-kafka-and-spark$ docker-compose down
```
#### Output
```
Stopping flaskwithkafkaandspark_kafka_1     ... done
Stopping flaskwithkafkaandspark_zookeeper_1 ... done
Stopping flaskwithkafkaandspark_spark_1     ... done
Stopping flaskwithkafkaandspark_mids_1      ... done
Removing flaskwithkafkaandspark_kafka_1     ... done
Removing flaskwithkafkaandspark_zookeeper_1 ... done
Removing flaskwithkafkaandspark_spark_1     ... done
Removing flaskwithkafkaandspark_mids_1      ... done
Removing network flaskwithkafkaandspark_default
```
#### Explanation
The Flask server was stopped by typing a Control-C to the terminal.  The Docker containers were then shut down, and messages acknowledging their being stopped and the Flask server's HTTP endoint removed were directed to the console.

    



