# Assignment 07 - bdandersen-berkeley-history.txt Annotations

**Brad Andersen**

**W205 - Summer 2019 - Doris Schioberg**

## Preparatory Work

Once in my GCP MIDS VM instance, changing directories to *course-content*, and updating the Git repository.

```
  448  cd w205/course-content
  449  git pull origin master
  450  cd ..
```
## MIDS, Kafka, Zookeeper and Spark Docker Container Definitions

Work is to be performed beneath the *kafka-with-spark* directory, created beneath the *w205* directory in my home directory.  The *docker-compose.yml* YAML file is to be copied from the assignment's directory within the *course-content* Git repository.

Descending into the *kafka-with-spark* directory, I examine *docker-compose.yml* using `vi`.

```
  451  mkdir spark-with-kafka
  452  cp course-content/07-Sourcing-Data/docker-compose.yml ./spark-with-kafka
  453  cd spark-with-kafka
  454  vi docker-compose.yml
```
  
## Bringing Docker Online

I bring Docker online as a background process, and check to see that the containers defined within the *docker-compose.yml* file have started without error.

```
  455  docker-compose up -d
  456  docker-compose ps
```

For some reason, the *kafka* container failed to come online, and attempting to create the *assignment07* topic fails.  **Within another terminal** (the history from which is not shown here) I check the logs, and see an error that makes me suspect that there might be conflict between the new *kafka* container and some residue from a previous instantiation of a *kafka* container.  I shut everything down, and bring everything back online again.  All is well now.

```
  458  docker-compose exec kafka kafka-topics --create --topic assignment07 --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
  459  docker down
  460  docker-compose down
  461  docker-compose images
  462  docker-compose up -d
  463  docker-compose ps
```

## Creation of the Kafka Topic to Which to Direct Messaging

Using `docker-compose`, I invoke Kafka in the *kafka* Docker container, and create a new topic named *assignment07*.  Only a single partition for the topic is created, and the `zookeeper` instance (listening on port 32181) is identified for managing Kafka synchronization should we wish to operate in a distributed environment (which we're not).

```
  464  docker-compose exec kafka kafka-topics --create --topic assignment07 --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
```

## Retrieval of the JSON Data File

I first retrieved the assignment's JSON-formatted data file using an incorrect URL.

```
  457  curl -L -o github-example-large.json https://goo.gl/Y4MD58
```

I retrieve the correct JSON-formatted data file from the documented location using the `curl` utility, copying it into the current (i.e. *kafka-with-spark*) directory.

```
  465  curl -L -o assessments-nested.json https://goo.gl/ME6hjp
```

## Streaming Data to the Kafka *assignment07* Topic

I invoke a command-line operation leveraging the `bash` shell of the `mids` Docker container to direct content of the JSON data file to the *assignment07* Kafka topic.  The command line operation leverages pipes, with output from the prior command being directed (i.e. piped) to the current command as follows:

* The JSON data file *assessments-nested.json* is directed to an output destination
* Output is directed to the `jq` utility, formatting the data to an easier understood representation
* Formatted JSON is serialized to the Kafka *assignment07* topic
* Once all operations are complete, the message 'Done producing assessment messages' is directed to the current console.

```
  468  docker-compose exec mids bash -c "cat /w205/spark-with-kafka/assessments-nested.json | jq '.[]' -c | kafkacat -P -b kafka:29092 -t assignment07 && echo 'Done producing assessment messages'"
```

## Data Manipulation within Spark's PySpark Interactive Python Session

I invoke *Spark* and instantiate a PySpark interactive Python session to examine and manipulate for potential use within an HDFS file system.

```
  469  docker-compose exec spark pyspark
```

My work with the data in the PySpark session is as follows:

### Retrieval of *assessments-nested.json* Data from Kafka

I retrieve the *assessments-nested.json* data previously streamed to topic *assignment07* in Kafka to the Python *msgs* variable, and examine its schema.  *key* and *value* values are represented in binary format.

```
>>> msgs = spark.read.format("kafka").option("kafka.bootstrap.servers", "kafka:29092").option("subscribe", "assignment07").option("startingOffsets", "earliest").option("endingOffsets", "latest").load()
>>> msgs
DataFrame[key: binary, value: binary, topic: string, partition: int, offset: bigint, timestamp: timestamp, timestampType: int]
>>> msgs.printSchema()
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 |-- timestampType: integer (nullable = true)
```

### Conversion of *key* and *value* Values to Strings of Characters

I cast the binary data maintained in the *key* and *value* values to strings of human-readable characters, positing the converted data into the *s_msgs* variable.  As expected, the data is maintained using a *DataFrame* object, and its number of rows is as anticipated (i.e. 3,280).

```
>>> s_msgs = msgs.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
>>> s_msgs.show()
+----+--------------------+
| key|               value|
+----+--------------------+
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
...
|null|{"keen_timestamp"...|
+----+--------------------+
only showing top 20 rows
>>> type(s_msgs)
<class 'pyspark.sql.dataframe.DataFrame'>
>>> s_msgs.count()
3280
```

### Examining the Data as JSON

In anticipation of storing data in HDFS, I want to examine and experiment with manipulating its structure when represented as JSON.  I import the *json* Python library, and retrieve the first line of data into variable *first_msg* formatted as JSON.

```
>>> import json
>>> first_msg = json.loads(s_msgs.select('value').take(1)[0].value)
>>> print(first_msg)
{'keen_timestamp': '1516717442.735266', 'max_attempts': '1.0', ... 'exam_name': 'Normal Forms and All That Jazz Master Class'}
```

### Examination of Nested JSON Data

As required by Project 2's instructions, I will need to select various elements of the data (i.e. values of JSON key/value pairs) from within the nested JSON structure.  The following `lambda` demonstrates the ability to retrieve the instance of the first JSON data element in a list of elements beneath the `questions` key.

```
>>> x = lambda n: first_msg['sequences']['questions'][n]
>>> x(1)
{'user_incomplete': False, 'user_correct': False, 'options': [{'checked': True, 'at': '2018-01-23T14:23:30.116Z', 'id': 'a35d0e80-8c49-415d-b8cb-c21a02627e2b', 'submitted': 1}, {'checked': False, 'correct': True, 'id': 'bccd6e2e-2cef-4c72-8bfa-317db0ac48bb'}, {'checked': True, 'at': '2018-01-23T14:23:41.791Z', 'id': '7e0b639a-2ef8-4604-b7eb-5018bd81a91b', 'submitted': 1, 'correct': True}], 'user_submitted': True, 'id': 'bbed4358-999d-4462-9596-bad5173a6ecb', 'user_result': 'incorrect'}
```

### Iterating over Nested JSON Data

Another ability to anticipate with Project 2's instructions is to iterate through the nested JSON structure of data, selecting individual elements.  The following code demonstrates how to descend within a JSON structure and selectively retrieve only the data required (in this instance, the `id`s associated with assessment questions' `options`.

I chose to isolate my data retrieval to a single JSON element, `id`, in order to prove to myself that I had the ability to complete the future task *and* to keep matters simple; attempting to retrieve multiple elements within the JSON would only serve to complicate my proof of concept.  Formal selection of the data that I will extract for inclusion within HDFS will occur with Assignment 08.

```
>>> option_ids = lambda o: print(o['id'])
>>> for q in first_ten['sequences']['questions']:       
...   for o in q['options']:
...     option_ids(o)
... 
49c574b4-5c82-4ffd-9bd1-c3358faf850d
f2528210-35c3-4320-acf3-9056567ea19f
d1bf026f-554f-4543-bdd2-54dcf105b826
a35d0e80-8c49-415d-b8cb-c21a02627e2b
bccd6e2e-2cef-4c72-8bfa-317db0ac48bb
7e0b639a-2ef8-4604-b7eb-5018bd81a91b
a9333679-de9d-41ff-bb3d-b239d6b95732
85795acc-b4b1-4510-bd6e-41648a3553c9
c185ecdb-48fb-4edb-ae4e-0204ac7a0909
77a66c83-d001-45cd-9a5a-6bba8eb7389e
59b9fc4b-f239-4850-b1f9-912d1fd3ca13
2c29e8e8-d4a8-406e-9cdf-de28ec5890fe
62feee6e-9b76-4123-bd9e-c0b35126b1f1
7f13df9c-fcbe-4424-914f-2206f106765c
```

## Cleanup

I shut down the Docker containers, check to ensure that the containers are no longer running, and then direct my command line history to *bdandersen-history.txt*.

```  
  470  docker-compose down
  471  docker-compose ps
  472  history > bdandersen-history.txt
```
