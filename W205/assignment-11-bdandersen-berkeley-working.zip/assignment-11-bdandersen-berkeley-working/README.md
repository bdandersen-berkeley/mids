# Assignment 11 - README.md

**Brad Andersen**

**W205 - Summer 2019 - Doris Schioberg**

## Assignment Summary

Using applications executing within several Docker containers and hosted on a Google Cloud virtual machine, a simple web application was written, deployed and tested.  Goals of the web application included:
* Develop a web application written in Python and founded upon the Flask web framework
* Receive HTTP GET requests using various URL endpoints
* Acknowledge receipt by sending a text message to the calling client in an HTTP response
* Log events received to Kafka as JSON objects to the `events` topic, including a handful of HTTP request headers
* Retrieve data from the Kafka `events` topic using Spark's PySpark command line.  Convert events represented in binary format to strings, direct the string representations to a `DataFrame`, and print the contents of the `DataFrame` to the PySpark console.

Following the prior activities, additional Python scripts were written or modified to perform the following:
* Direct events streamed from Kafka to the Hadoop HDFS file system, rather than to the console
* Intercept events immediately following their retrieval from Kafka, and modify their content prior to directing them to HDFS
* Filter the previously-modified events based upon their event "event_type" attribute, print default and sword-purchasing events separately, and restrict the output of events with all other event types.

## *docker-compose.yml*

```
--
version: '2'
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    environment:
      ZOOKEEPER_CLIENT_PORT: 32181
      ZOOKEEPER_TICK_TIME: 2000
    expose:
      - "2181"
      - "2888"
      - "32181"
      - "3888"
    extra_hosts:
      - "moby:127.0.0.1"

  kafka:
    image: confluentinc/cp-kafka:latest
    depends_on:
      - zookeeper
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:32181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    expose:
      - "9092"
      - "29092"
    extra_hosts:
      - "moby:127.0.0.1"

  cloudera:
    image: midsw205/cdh-minimal:latest
    expose:
      - "8020" # nn
      - "50070" # nn http
      - "8888" # hue
    #ports:
    #- "8888:8888"
    extra_hosts:
      - "moby:127.0.0.1"

  spark:
    image: midsw205/spark-python:0.0.5
    stdin_open: true
    tty: true
    expose:
      - "8888"
    ports:
      - "8888:8888"
    volumes:
      - "~/w205:/w205"
    command: bash
    depends_on:
      - cloudera
    environment:
      HADOOP_NAMENODE: cloudera
    extra_hosts:
      - "moby:127.0.0.1"

  mids:
    image: midsw205/base:latest
    stdin_open: true
    tty: true
    expose:
      - "5000"
    ports:
      - "5000:5000"
    volumes:
      - "~/w205:/w205"
    extra_hosts:
      - "moby:127.0.0.1"
```

## *game_api_11.py*
```
#!/usr/bin/env python
  
import json
from kafka import KafkaProducer
from flask import Flask, request

app = Flask(__name__)
KAFKA_EVENT_LOGGER = KafkaProducer(bootstrap_servers = "kafka:29092")
KAFKA_EVENT_TOPIC = "events"

def log_to_kafka(topic, event):
    event.update(request.headers)
    KAFKA_EVENT_LOGGER.send(topic, json.dumps(event).encode())

@app.route("/")
def default_response():
    default_event = {"event_type": "default"}
    log_to_kafka(KAFKA_EVENT_TOPIC, default_event)
    return "This is the default response!\n"

@app.route("/purchase_a_sword")
def purchase_sword():
    purchase_sword_event = {"event_type": "purchase_sword"}
    log_to_kafka(KAFKA_EVENT_TOPIC, purchase_sword_event)
    return "Sword Purchased!\n"
```

## Procedural Steps

### Docker Container Setup and Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~$ cd w205
bdandersen@bdandersen-mids-w205:~/w205$ mkdir spark-from-files
bdandersen@bdandersen-mids-w205:~/w205$ cd spark-from-files/
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ cp ~/w205/course-content/11-Storing-Data-III/docker-compose.yml .
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ cp ~/w205/course-content/11-Storing-Data-III/*.py .
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose up -d
```
#### Console Output
```
Starting sparkfromfiles_zookeeper_1 ... 
Starting sparkfromfiles_zookeeper_1
Starting sparkfromfiles_cloudera_1 ... 
Starting sparkfromfiles_mids_1 ... 
Starting sparkfromfiles_cloudera_1
Starting sparkfromfiles_zookeeper_1 ... done
Starting sparkfromfiles_kafka_1 ... 
Starting sparkfromfiles_cloudera_1 ... done
Starting sparkfromfiles_spark_1 ... 
Starting sparkfromfiles_spark_1 ... done
```
#### Explanation
A directory in which to maintain assignment files -- `spark-from-files` -- was created beneath the `w205` directory in my user's home directory.  A docker-compose YAML file and all files with the `*.py` file extension were copied from the local ``course-content`` Git repository, and Docker containers were brought online using docker-compose invoked as a background process.

### Examining Hadoop File System Directories
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec cloudera hadoop fs -ls /tmp/
```
#### Console Output
```
Found 2 items
drwxrwxrwt   - mapred mapred              0 2018-02-06 18:27 /tmp/hadoop-yarn
drwx-wx-wx   - root   supergroup          0 2019-07-15 23:24 /tmp/hive
```
#### Explanation
The Hadoop HDFS file system was queried for the contents of its `/tmp` directory.  Metadata associated with its contents -- two subdirectories named `hadoop-yarn` and `hive` -- was printed to the console.

### Creating the Kafka Topic
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec kafka kafka-topics --create --topic events --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
```
#### Console Output
```
Created topic "events".
```
#### Explanation
Kafka (running in a separate Docker container) was executed and a new Kafka topic -- `events` -- was created to which to stream web application logging messages.

### Web Application Development and Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ vi game_api_11.py
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec mids env FLASK_APP=/w205/spark-from-files/game_api_11.py flask run --host 0.0.0.0
```
#### Output
```
 * Serving Flask app "game_api_11"
 * Running on http://0.0.0.0:5000/ (Press CTRL+C to quit)
 ```
#### Explanation
The Python web application -- detailed above in *game_api_11.py* -- was written.  Conforming to the Flask web framework's conventions, two endpoints (i.e. "routes") were defined using Flask's function decorator `@app.route()`:
* `@app.route("/")` -- Receiving HTTP requests beneath the application's base URL
* `@app.route("/purchase_a_sword")` -- Receiving HTTP requests beneath the application's `/purchase_a_sword` URL
The application was modified from the prior week's Python script by consolidating common Kafka logging functionality in the *`log_to_kafka()`* function.

Both endpoints log HTTP requests received to Kafka, and return a text message in an HTTP response.
The Flask framework (within the separate `mids` Docker container) was executed, and *game_api_11.py* was identified as the script to which to direct events.  The Flask server began executing, and acknowledged invocation with messages that included the URL beneath which the application is running:
* `http://127.0.0.1` identifies the local host's IP address
* `:5000` identifies the port number upon which the Flask server is listening

### Web Application Test Invocation
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec mids curl http://localhost:5000/
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec mids curl http://localhost:5000/purchase_a_sword
```
#### Output (Client Terminal)
```
This is the default response!
Sword Purchased!
```
#### Output (Server Terminal)
``` 
127.0.0.1 - - [26/Jul/2019 17:36:48] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [26/Jul/2019 17:37:04] "GET /purchase_a_sword HTTP/1.1" 200 -
```
#### Explanation
From a separate client terminal (on the same virtual machine as the Flask server), two HTTP GET requests were sent (using *`curl`*, the command-line HTTP client) to the Flask server, identifying the two endpoints defined within *game_api_11.py*.  HTTP responses were received, and the textual payload in each matched those defined within the Python script.

In the terminal in which the Flask server is executing, Flask acknowledged the receipt of the HTTP requests by logging each event to the console.  Information logged includes:
* Server's IP address
* Timestamp of receipt of HTTP request
* HTTP request (identifying the HTTP method, the endpoint, the version of the HTTP protocol used, and the HTTP response status code 200 indicating success)

### Check of Kafka Topic
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec mids bash -c "kafkacat -C -b kafka:29092 -t events -o beginning -e"
```
#### Output
```
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
% Reached end of topic events [0] at offset 2: exiting
```
#### Explanation
The `kafkacat` command was executed (running in a separate Docker container) to direct events logged in the `events` topic to the terminal.  The two messages associated with the HTTP GET requests sent to endpoints defined in *game_api_11.py* were correctly logged, formatted as JSON.

### Programmatic Extraction of Events, Streamed to HDFS
#### Commands Executed
Template Python script `extract_events.py` was copied to `extract_events_11.py` for editing.
```
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec spark spark-submit /w205/spark-from-files/extract_events_11.py
```
#### Output
```
Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
19/07/26 17:48:27 INFO SparkContext: Running Spark version 2.2.0
19/07/26 17:48:27 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
19/07/26 17:48:27 INFO SparkContext: Submitted application: ExtractEventsJob
...
19/07/26 17:48:54 INFO SparkContext: Successfully stopped SparkContext
19/07/26 17:48:54 INFO ShutdownHookManager: Shutdown hook called
19/07/26 17:48:54 INFO ShutdownHookManager: Deleting directory /tmp/spark-000d8899-76fc-4ef5-9132-c209c56f50b1
19/07/26 17:48:54 INFO ShutdownHookManager: Deleting directory /tmp/spark-000d8899-76fc-4ef5-9132-c209c56f50b1/pyspark-9ae6d783-b6d3-4fef-a2bb-81266d4aaf3a
```
#### Explanation
Upon the execution of Python script `extract_events_11.py`, events are programmatically streamed from Kafka topic `events` in a similar fashion to how we have streamed events manually from the console before.  Events streamed from Kafka are written to a Parquet file managed by Hadoop on the HDFS file system before the script completes execution.  The Python script is executed in a Spark session.

### Check for Streamed Events in HDFS
#### Commands Executed
```
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec cloudera hadoop fs -ls /tmp/
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec cloudera hadoop fs -ls /tmp/extracted_events
```
#### Output
```
Found 3 items
drwxr-xr-x   - root   supergroup          0 2019-07-26 17:48 /tmp/extracted_events
drwxrwxrwt   - mapred mapred              0 2018-02-06 18:27 /tmp/hadoop-yarn
drwx-wx-wx   - root   supergroup          0 2019-07-15 23:24 /tmp/hive

Found 2 items
-rw-r--r--   1 root supergroup          0 2019-07-26 17:48 /tmp/extracted_events/_SUCCESS
-rw-r--r--   1 root supergroup       1163 2019-07-26 17:48 /tmp/extracted_events/part-00000-d3c828a1-3aa5-4bfd-bcc6-07562dd2409b-c000.snappy.parquet
```
#### Explanation
The Hadoop HDFS file system was queried for the contents of its `/tmp` and `/tmp/extracted_events` directories.  Metadata associated with their contents was printed to the console, ensuring that the Python script executed in the prior step performed properly.

### Transforming Events
#### Commands Executed
Template Python script `transform_events.py` was copied to `transform_events_11.py` for editing.  Within the Python script, the event attribute "host" was changed from "moe" to "googley-moogley" to help ensure that the script was operating properly.
```
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec spark spark-submit /w205/spark-from-files/transform_events_11.py
```
#### Output
```
<much_spark_session_diagnostics>
...
+------+-------------+---------------+-----------+--------------+--------------------+
|Accept|Cache-Control|           Host| User-Agent|    event_type|           timestamp|
+------+-------------+---------------+-----------+--------------+--------------------+
|   */*|     no-cache|googley-moogley|curl/7.47.0|       default|2019-07-26 17:36:...|
|   */*|     no-cache|googley-moogley|curl/7.47.0|purchase_sword|2019-07-26 17:37:...|
+------+-------------+---------------+-----------+--------------+--------------------+
...
<much_spark_session_diagnostics>
```
#### Explanation
The Python script `transform_events_11.py` operates similarly to `extract_events_11.py`.  However, raw events streamed from Kafka are first modified to include event attributes "Host" and "Cache-Control", then transformed into a data frame object and printed to the standard output.

### Separating Events
#### Commands Executed
Template Python script `separate_events.py` was copied to `separate_events_11.py` for editing.  Within the Python script, the event attribute "host" was changed from "moe" to "googley-redux" to help ensure that the script was operating properly.
```
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose exec spark spark-submit /w205/spark-from-files/separate_events_11.py
```
#### Output
```
<much_spark_session_diagnostics>
...
+------+-------------+-------------+-----------+--------------+--------------------+
|Accept|Cache-Control|         Host| User-Agent|    event_type|           timestamp|
+------+-------------+-------------+-----------+--------------+--------------------+
|   */*|     no-cache|googley-redux|curl/7.47.0|purchase_sword|2019-07-26 17:37:...|
+------+-------------+-------------+-----------+--------------+--------------------+
...
<much_spark_session_diagnostics>
...
+------+-------------+-------------+-----------+----------+--------------------+
|Accept|Cache-Control|         Host| User-Agent|event_type|           timestamp|
+------+-------------+-------------+-----------+----------+--------------------+
|   */*|     no-cache|googley-redux|curl/7.47.0|   default|2019-07-26 17:36:...|
+------+-------------+-------------+-----------+----------+--------------------+
...
<much_spark_session_diagnostics>
```
#### Explanation
The Python script `separate_events_11.py` operates similarly to `transform_events_11.py`.  However, events are filtered into one of two categories -- sword purchases and default hits -- using a literal string comparison on the event's "event_type" attribute.  Sword purchase events and default hit events are printed to the standard output separately.

Note that any event that had been logged whose "event_type" event attribute was neither "purchase_sword" nor "default" would not be printed.

Both the transformation and separation scripts are brittle, and would require manual updates if the event schema changed.  In production, it would be more useful (and less error prone) if the schema could be dynamically read from a separate file, or even if string literals were defined toward the top of the script so that values only needed to be changed once.

### Flask Server and Docker Container Halt
#### Commands Executed
```
^C
bdandersen@bdandersen-mids-w205:~/w205/spark-from-files$ docker-compose down
```
#### Output
```
Stopping sparkfromfiles_kafka_1     ... done
Stopping sparkfromfiles_spark_1     ... done
Stopping sparkfromfiles_mids_1      ... done
Stopping sparkfromfiles_cloudera_1  ... done
Stopping sparkfromfiles_zookeeper_1 ... done
Removing sparkfromfiles_kafka_1     ... done
Removing sparkfromfiles_spark_1     ... done
Removing sparkfromfiles_mids_1      ... done
Removing sparkfromfiles_cloudera_1  ... done
Removing sparkfromfiles_zookeeper_1 ... done
Removing network sparkfromfiles_default
```
#### Explanation
The Flask server was stopped by typing a Control-C to the terminal.  The Docker containers were then shut down, and messages acknowledging their being stopped and the Flask server's HTTP endoint removed were directed to the console.
