# Assignment 05 - bdandersen-berkeley-history.txt Annotations

**Brad Andersen**

**W205 - Summer 2019 - Doris Schioberg**

## Preparatory Work

Once in my GCP MIDS VM instance, changing directories to *w205/course-content*, and updating the Git repository.

```
  169  cd w205
  170  ls
  171  cd course-content
  172  git pull
```

## Redis Standalone Docker Container

Changing directories to the previously-created *redis-standalone* directory, examining the *docker-compose.yml* file, and attempting to start the Redis Docker container.

```
  173  cd redis-standalone
  174  cd ../redis-standalone
  175  ls
  176  vi docker-compose.yml
  177  docker run -d --name redis -p 6379:6379 redis
```

Errors occurred stating that the existing Redis Docker container was still active.  Attempts to kill it using the *bash* `$()` syntax failed, so instances were killed and containers removed by explicity identifying their hexadecimal ids on the command line.

```
  178  docker ps
  179  docker-compose ps
  180  docker ps -q -a
  181  docker kill $(docker ps -q)
  182  docker kill --help
  183  docker kill ba65ef6df14f 8696935f3e37 41742e92cfa6
  184  docker rm ba65ef6df14f 8696935f3e37 41742e92cfa6
```
  
Once the Docker containers were removed, starting a new Docker container, ensuring that it's operational, then killing and removing it.

```
  185  docker run -d --name redis -p 6379:6379 redis
  186  docker ps
  187  docker kill redis
  188  docker rm redis
  189  docker ps
```

## Redis Cluster Docker Containers

Changing directories to the previously-created *redis-cluster* directory and examining the *docker-compose.yml* file.

```
  190  cd ../redis-cluster/
  191  ls
  192  vi docker-compose.yml
```
  
Starting the *mids* and *redis* Docker containers defined in the *docker-compose.yml* file, and checking that they're both operational.

```
  193  docker-compose up -d
  194  docker-compose ps
  195  docker-compose logs redis | tail
```

Dropping into a bash console within the *mids* Docker container.

```
  196  docker-compose exec mids bash
```

## Bonus iPython Redis Exercise

At this point, I invoked *ipython* from the command line, connected to the Redis instance in the other Docker container, and set, examined and retrieved Redis keys with the following:

```
root@3b432c964a75:~# ipython
Python 3.5.2 (default, Nov 23 2017, 16:37:01) 
Type 'copyright', 'credits' or 'license' for more information
IPython 6.3.0 -- An enhanced Interactive Python. Type '?' for help.

In [1]: import redis

In [2]: r = redis.Redis(host = 'redis', port = 6379)

In [3]: r.set('name_first', 'Brad')
Out[3]: True

In [4]: r.set('name_last', 'Andersen')
Out[4]: True

In [5]: r.keys()
Out[5]: [b'name_last', b'name_first']

In [6]: r.get('name_first')
Out[6]: b'Brad'

In [7]: exit
```

## Cleanup

Shutting down the Docker containers.

```
  197  docker-compose down
```

Echoing *bash* history to a text file.

```
  198  history > bdandersen-berkeley-history.txt
```
