# Pare assessment delivery data to an abbreviated, flattened JSON representation
#
import io
import json
import sys

# Exam-related assessment attributes to retrieve and copy to pared assessment delivery JSON
EXAM_ATTRIBUTES = ["keen_id", "keen_created_at", "keen_timestamp", "exam_name", "certification"]

# Individual delivery exam-related assessent attributes to retrieve ...
DELIVERY_ATTRIBUTES = ["base_exam_id", "user_exam_id", "max_attempts", "started_at"]

# Individual delivery exam-related assessment aggregate attributes to retrieve ...
SEQUENCES_ATTRIBUTE = "sequences"
COUNTS_ATTRIBUTE = "counts"
DELIVERY_AGGREGATE_ATTRIBUTES = ["total", "answered", "submitted", "correct", "incorrect", "incomplete", "all_correct"]

def pare_json(json_file):
    '''
    Iterate through JSON-formatted assessment items, and generate a pared-down, flattened JSON
    representation.

    The pared-down representation of each assessment delivery removes the detail associated with
    each question delivered, making for a more easily-understood assessment delivery document.

    Arguments
    ---------
    json_file - File object associated with the assessment JSON file

    Returns
    -------
    Text representation of the pared-down, flattened JSON
    '''
    assessments = json.load(json_file)

    # Iterate through all assessments in the JSON file
    pared_assessments = []
    for assessment in assessments:
        pared_assessment = {}

        # Retrieve exam, individual delivery, and delivery aggregate attributes, ensuring that
        # those attributes that may be missing in the original assessment data are specified in
        # the pared-down representation (albeit with empty strings as values)
        for attr in EXAM_ATTRIBUTES:
            try:
                pared_assessment[attr] = assessment[attr]
            except KeyError as keyErr:
                pared_assessment[attr] = ""

        for attr in DELIVERY_ATTRIBUTES:
            try:
                pared_assessment[attr] = assessment[attr]
            except KeyError as keyErr:
                pared_assessment[attr] = ""

        for attr in DELIVERY_AGGREGATE_ATTRIBUTES:
            try:
                pared_assessment[attr] = assessment[SEQUENCES_ATTRIBUTE][COUNTS_ATTRIBUTE][attr]
            except KeyError as keyErr:
                pared_assessment[attr] = ""

        # Add the pared-down assessment delivery data to the collection of data
        pared_assessments.append(pared_assessment)

    # Return a textual representation of the JSON assessment exam delivery data
    return json.dumps(pared_assessments)

def usage():
    '''
    Print pare_assessment_data.py usage data
    '''
    print("Usage:")
    print("  pare_assessment_data.py <pathname_of_assessment_json>")

if len(sys.argv) != 2:
    usage()
    sys.exit()

try:
    print(pare_json(io.FileIO(sys.argv[1])))

except FileNotFoundError as fnfErr:
    usage()
    raise fnfErr

except Exception as ex:
    print("Unexpected exception")
    raise ex