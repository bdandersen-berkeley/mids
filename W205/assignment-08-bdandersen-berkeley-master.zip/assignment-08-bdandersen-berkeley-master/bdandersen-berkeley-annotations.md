# Assignment 08 - bdandersen-berkeley-history.txt Annotations

**Brad Andersen**

**W205 - Summer 2019 - Doris Schioberg**

## Preparatory Work

Once in my GCP MIDS VM instance, changing directories to *course-content*, and updating the Git repository.  Doing the same for my Assignment 08 repository

```
  556  cd w205/course-content
  557  git pull origin master
  558  cd ../assignment-08-bdandersen-berkeley
  559  git checkout working
  560  git pull origin working
  561  cd ..
```
## MIDS, Kafka, Zookeeper, Spark and Hadoop (cloudera) Docker Container Definitions

Work is to be performed beneath the *kafka-with-spark-and-hdfs* directory, created beneath the *w205* directory in my home directory.  The *docker-compose.yml* YAML file is to be copied from the assignment's directory within the *course-content* Git repository.

Descending into the *kafka-with-spark-hdfs* directory, I examine *docker-compose.yml* using `vi`.

```
  562  mkdir spark-with-kafka-and-hdfs
  563  cp course-content/08-Querying-Data/docker-compose.yml ./spark-with-kafka-and-hdfs/
  564  cd spark-with-kafka-and-hdfs/
  565  vi docker-compose.yml 
```

## Copying `pare_assessment_data.py` Python Script

Because of the complexity of the assessment JSON, as well as the barely-usable PySpark command-line interface, I chose to perform my editing and paring of the assessment data prior to streaming the JSON to Kafka.  I therefore copy my Python script, `pare_assessment_data.py`, from my Assignment 08 Git repository.

```
  566  cp ../assignment-08-bdandersen-berkeley/pare_assessment_data.py .
  567  vi pare_assessment_data.py 
```

## Retrieval of the JSON Data File

I retrieve the correct JSON-formatted data file from the documented location using the `curl` utility, copying it into the current (i.e. *kafka-with-spark-and-hdfs*) directory.

```
  568  curl -L -o assessments.json https://goo.gl/ME6hjp
  569  vi assessments.json
```

## Preparation of the Pared, Flattened JSON Assessment Data

My modifications to the assessment data for easier use by data scientists included the following:

* The structure of the nested JSON beneath the `sequences` attribute wasn't intuitive.  My goal was to create a pared representation of the JSON data in a flattened structure of simple key-value pairs for simplicity.
* Another goal was to provide the test delivery data scientists with a higher-level representation of the assessment data, eliminating the granularity of the `sequences -> questions` structure.  Instead, I retrieved just the aggregate values -- the metrics beneath the `sequences -> counts` structure -- and included them within each pared assessment JSON object.
* I flattened the JSON hierarchy to a single level for ease of use.  Doing so abandoned normalization tenets, but I felt that the flat structure would be to the data scientists' advantage.
* I reordered the assessment data, ordering key-value pairs as follows:
  * Exam data
  * Individual assessment/delivery data
  * Metrics/aggregate values of individual assessment/delivery data
  
See `pare_assessment_data.py` for further details.

I made certain that I was using the correct version of a Python interpreter, and then created the pared, flattened JSON assessment data from the original assessment JSON.

```
  570  python --version
  571  which python3
  572  python3 pare_assessment_data.py assessments.json > assessments_pared.json
  573  vi assessments_pared.json
```

## Bringing Docker Online

I bring Docker online as a background process, and check to see that the containers defined within the *docker-compose.yml* file have started without error.

```
  574  docker-compose up -d
  575  docker-compose ps
```

## Creation of the Kafka Topic to Which to Direct Messaging

Using `docker-compose`, I invoke Kafka in the *kafka* Docker container, and create a new topic named *assignment08*.  Only a single partition for the topic is created, and the `zookeeper` instance (listening on port 32181) is identified for managing Kafka synchronization should we wish to operate in a distributed environment (which we're not).

In my first attempt, I mistakenly omitted the `exec` command.

```
  576  docker-compose kafka kafka-topics --create --topic assignment08 --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
  577  docker-compose exec kafka kafka-topics --create --topic assignment08 --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
```

## Streaming Data to the Kafka *assignment08* Topic

I invoke a command-line operation leveraging the `bash` shell of the `mids` Docker container to direct content of the JSON data file to the *assignment08* Kafka topic.  The command line operation leverages pipes, with output from the prior command being directed (i.e. piped) to the current command as follows:

* The JSON data file *assessments_pared.json* is directed to an output destination
* Output is directed to the `jq` utility, formatting the data to an easier understood representation
* Formatted JSON is serialized to the Kafka *assignment08* topic
* Once all operations are complete, the message 'Done producing pared assessment messages' is directed to the current console.

```
  578  docker-compose exec mids bash -c "cat /w205/spark-with-kafka-and-hdfs/assessments_pared.json | jq '.[]' -c | kafkacat -P -b kafka:29092 -t assignment08 && echo 'Done producing pared assessment messages'"
```

## Data Manipulation within Spark's PySpark Interactive Python Session

I invoke *Spark* and instantiate a PySpark interactive Python session to examine and manipulate for potential use within an HDFS file system.

```
  579  docker-compose exec spark pyspark
```

My work with the data in the PySpark session is as follows:

### Retrieval of *assessments-pared.json* Data from Kafka

I retrieve the *assessments-nested.json* data previously streamed to topic *assignment07* in Kafka to the Python *msgs* variable, and examine its schema.  *key* and *value* values are represented in binary format.

```
>>> pared = spark.read.format("kafka").option("kafka.bootstrap.servers", "kafka:29092").option("subscribe", "assignment08").option("startingOffsets", "earliest").option("endingOffsets", "latest").load()
>>> pared
DataFrame[key: binary, value: binary, topic: string, partition: int, offset: bigint, timestamp: timestamp, timestampType: int]
>>> msgs.printSchema()
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 |-- timestampType: integer (nullable = true)
```

### Conversion of *key* and *value* Values to Strings of Characters

I cast the binary data maintained in the *key* and *value* values to strings of human-readable characters, positing the converted data into the *s_msgs* variable.  As expected, the data is maintained using a *DataFrame* object, and its number of rows is as anticipated (i.e. 3,280).

```
>>> pared_cast = pared.selectExpr("CAST(value AS STRING)")
>>> type(pared_cast)
<class 'pyspark.sql.dataframe.DataFrame'>
>>> pared_extracted = pared_cast.rdd.map(lambda x: Row(**json.loads(x.value))).toDF()
```

### Serializing Data to an HDFS File Store

I write the pared, flattened assessment JSON data to a parquet file, serializing it to HDFS.  I then check to ensure that it has successfully been written to the `tmp` directory.

```
>>> pared_extracted.write.parquet("/tmp/pared_extracted")
```

From a second terminal, I ensure that the file was indeed written:

```
bdandersen@bdandersen-mids-w205:~/w205/spark-with-kafka-and-hdfs$ docker-compose exec cloudera hadoop fs -ls /tmp/pared_extracted
Found 2 items
-rw-r--r--   1 root supergroup          0 2019-07-05 19:54 /tmp/pared_extracted/_SUCCESS
-rw-r--r--   1 root supergroup    2963354 2019-07-05 19:54 /tmp/pared_extracted/part-00000-2fb91a0b-3e99-46ff-a6e7-149c8618623a-c000.snappy.parquet
```

## Cleanup

I shut down the Docker containers, check to ensure that the containers are no longer running, and then direct my command line history to *bdandersen-berkeley-history.txt*.

```  
  580  docker-compose down
  581  docker-compose ps
  582  history > bdandersen-berkeley-history.txt
```
