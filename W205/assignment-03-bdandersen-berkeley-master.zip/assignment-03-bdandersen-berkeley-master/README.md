# template-activity-03


# Query Project

- In the Query Project, you will get practice with SQL while learning about
  Google Cloud Platform (GCP) and BiqQuery. You'll answer business-driven
  questions using public datasets housed in GCP. To give you experience with
  different ways to use those datasets, you will use the web UI (BiqQuery) and
  the command-line tools, and work with them in jupyter notebooks.

- We will be using the Bay Area Bike Share Trips Data
  (https://cloud.google.com/bigquery/public-data/bay-bike-share). 

#### Problem Statement
- You're a data scientist at Ford GoBike (https://www.fordgobike.com/), the
  company running Bay Area Bikeshare. You are trying to increase ridership, and
  you want to offer deals through the mobile app to do so. What deals do you
  offer though? Currently, your company has three options: a flat price for a
  single one-way trip, a day pass that allows unlimited 30-minute rides for 24
  hours and an annual membership. 

- Through this project, you will answer these questions: 
  * What are the 5 most popular trips that you would call "commuter trips"?
  * What are your recommendations for offers (justify based on your findings)?


## Assignment 03 - Querying data from the BigQuery CLI - set up 

### What is Google Cloud SDK?
- Read: https://cloud.google.com/sdk/docs/overview

- If you want to go further, https://cloud.google.com/sdk/docs/concepts has
  lots of good stuff.

### Get Going

- Install Google Cloud SDK: https://cloud.google.com/sdk/docs/

- Try BQ from the command line:

  * General query structure

    ```
    bq query --use_legacy_sql=false '
        SELECT count(*)
        FROM
           `bigquery-public-data.san_francisco.bikeshare_trips`'
    ```

### Queries

1. Rerun last week's queries using bq command line tool (Paste your bq
   queries):

- What's the size of this dataset? (i.e., how many trips)

```
brad@ryzen:/opt/google/google-cloud-sdk$ bq query --use_legacy_sql=false '
> SELECT COUNT(trip_id)
> FROM `bigquery-public-data.san_francisco.bikeshare_trips`
> '
Waiting on bqjob_r1deaf0366aafdab6_0000016adb8f8ae4_1 ... (0s) Current status: R                                            
Waiting on bqjob_r1deaf0366aafdab6_0000016adb8f8ae4_1 ... (0s) Current status: DONE   
+--------+
|  f0_   |
+--------+
| 983648 |
+--------+

```

- What is the earliest start time and latest end time for a trip?

```
brad@ryzen:/opt/google/google-cloud-sdk$ bq query --use_legacy_sql=false '      
> SELECT 
>   DATETIME(MIN(start_date), "-07:00") AS Earliest_start_date, 
>   DATETIME(MAX(end_date), "-07:00") AS Latest_end_date
> FROM `bigquery-public-data.san_francisco.bikeshare_trips` 
> '
Waiting on bqjob_r660d90c13855373e_0000016adb9179ab_1 ... (0s) Current status: R
Waiting on bqjob_r660d90c13855373e_0000016adb9179ab_1 ... (0s) Current status: DONE   
+---------------------+---------------------+
| Earliest_start_date |   Latest_end_date   |
+---------------------+---------------------+
| 2013-08-29T02:08:00 | 2016-08-31T16:48:00 |
+---------------------+---------------------+
```

- How many bikes are there?

```
brad@ryzen:/opt/google/google-cloud-sdk$ bq query --use_legacy_sql=false '
> SELECT COUNT(DISTINCT(bike_number)) AS Unique_bike_numbers 
> FROM `bigquery-public-data.san_francisco.bikeshare_trips` 
> '
Waiting on bqjob_r27f063ae3706853f_0000016adb933d75_1 ... (0s) Current status: R      
Waiting on bqjob_r27f063ae3706853f_0000016adb933d75_1 ... (0s) Current status: DONE   
+---------------------+
| Unique_bike_numbers |
+---------------------+
|                 700 |
+---------------------+
```

2. New Query (Paste your SQL query and answer the question in a sentence):

- How many trips are in the morning vs in the afternoon?

Because of the ambiguity in the question, it's necessary to answer two questions which exist:

- _What are the temporal bounds of "morning" and "afternoon" (e.g. When does morning begin and end?)_
- _Can trips begun "in the morning" continue into the afternoon, or must they also end in the morning?_ And similarly, _Can trips begun "in the afternoon" continue into the evening, or must they also end in the afternoon?_

Answering these questions will not only assist in this query, but help answer subsequent questions in the query project's analysis.

For the following query, the following temporal divisions in the day will be used:

| Division | Begins | Ends (Exclusive) |
| -------- | ------ | ---------------- |
| Morning | 5:00 am | 12:00 pm |
| Afternoon | 12:00 pm | 6:00 pm |
| Evening | 6:00 pm | 9:00 pm |
| Night | 9:00 pm | 5:00 am |

In addition, the query assumes that a trip "begun in the morning" must **also** end in the morning, and a trip "begun in the afternoon" must **also** end in the afternoon.

Note, too, that querying columns of type _datetime_ within table _bikeshare_trips_ identifies UTC as the datetime value's time zone **within the BiqQuery web-based query editor**:

![](./images/bq-ui_erroneous-timezone-in-datetime.png)

Documentation associated with the _bikeshare_trips_ table explicity identifies that all _datetime_ values are maintained using PST for timezone, not UTC.  Further analysis later in this document visually demonstrates that _datetime_ values are, indeed, maintained using PST.

```
brad@ryzen:/opt/google/google-cloud-sdk$ bq query --use_legacy_sql=false '
SELECT (
  SELECT COUNT(*)
  FROM `bigquery-public-data.san_francisco.bikeshare_trips` 
  WHERE
    TIME(start_date) >= "05:00:00" AND
    TIME(end_date) < "12:00:00"
) AS trip_count_morning,
(
  SELECT COUNT(*)
  FROM `bigquery-public-data.san_francisco.bikeshare_trips` 
  WHERE
    TIME(start_date) >= "12:00:00" AND
    TIME(end_date) < "18:00:00"
) AS trip_count_afternoon
'
Waiting on bqjob_r42f92661040ca7ea_0000016b002f7ac6_1 ... (0s) Current status: DONE   
+--------------------+----------------------+
| trip_count_morning | trip_count_afternoon |
+--------------------+----------------------+
|             392830 |               368289 |
+--------------------+----------------------+

```
### Project Questions
Identify the main questions you'll need to answer to make recommendations (list
below, add as many questions as you need).

- Question 1: What constitutes a "commuter trip"?  Likely parameters include time of day, length of trip, source and destination stations being dissimilar, day of week, and type of membership of the rider.

- Question 2: What is the current distribution of trips taken across 24-hour intervals for various criteria including weekdays, weekends, types of membership, etc.

- Question 3: What are current distributions of bike trips' lengths of time?  Would there be any incentive to offer specials to individuals in increments of time other than the all-day 30-minute increment?

- Question 4: How does ridership compare across the two types of memberships recorded with rides?  Is ridership changing over time (e.e. fewer rides among annual membership customers suggesting that the annual membership offer is lessening in popularity)?

- Question 5: How does ridership compare across stations associated with each "landmark" (e.g. "Redwood City", "Palo Alto")?  
### Answers

Answer at least 4 of the questions you identified above You can use either
BigQuery or the bq command line tool.  Paste your questions, queries and
answers below.

#### Question 1

_What constitutes a "commuter trip"?  Likely parameters include time of day, length of trip, source and destination stations being dissimilar, day of week, and type of membership of the rider._

According to the Oxford English Dictionary, [_commute_](https://en.oxforddictionaries.com/definition/commute) is defined as follows:
  
  > A regular journey of some distance to and from one's place of work.
  
For the purpose of identifying bike trips that are likely commuter trips, additional contextual bounds must be placed upon the definition.  Such bounds include:
  
  * _Time of day_ - Workdays in the United States are often considered to be eight hours long, beginning at 9 am and ending at 5 pm.
  * _Length of trip_ - With respect to bicycle commutes, trips shouldn't exceed a certain length of time.
  * _Day of week_ - In the United States, work weeks typically assume days between Monday and Friday, with Saturday and Sunday being considered "weekends" during which workers typically do not commute to and from their place of work.
  * _Type of rider membership_ - Bicycle commuting requires planning and dedication.  Therefore, it _could_ be assumed that those who commute by bicycle commute _regularly_, and are therefore more likely to subscribe to memberships spanning a greater length of time (e.g. subscribing to an annual rider membership as opposed to purchasing individual trips).
  
The following query provides historic, aggregated bike trip frequency data helpful for both refining our definition of a _commuter trip_ as well as helping answer questions associated with frequency that may prove helpful in creating recommendations for offers.  Data is aggregated into 15-minute intervals across a 24-hour, daylong period, although the query can be modified for greater or less temporal granularity.
  
```
WITH temporal_category AS (
  SELECT
    EXTRACT(HOUR FROM start_date) AS hour,
    CAST(FLOOR(EXTRACT(MINUTE FROM start_date) / 15) * 15 AS INT64) AS quarter,
    EXTRACT(DAYOFWEEK FROM start_date) > 1 AND EXTRACT(DAYOFWEEK FROM start_date) < 7 AS weekday,
    start_station_id != end_station_id AS one_way,
    duration_sec
  FROM `bigquery-public-data.san_francisco.bikeshare_trips`
)
SELECT 
  TIME(hour, quarter, 0) AS start_time, 
  COUNT(hour) AS total_trips,
  weekday,
  one_way,
  AVG(duration_sec) / 60 AS average_duration_minutes
FROM temporal_category
GROUP BY hour, quarter, weekday, one_way
ORDER BY hour, quarter, weekday DESC, one_way DESC
```

##### Time of Day

The distribution of all bike trip frequencies across a 24-hour period -- comparing weekend and weekday trips -- can be visualized as follows:
  
![](./images/weekends-weekdays.png)

The bimodal distribution of weekday bike trips across a 24-hour period clearly demonstrates heavier use of bikes during anticipated morning and evening commute periods.  There is also a slight increase in mid-day ridership, both on weekdays as well as weekends.

##### Duration of Trip

The distribution of average bike trip durations across a 24-hour time period -- comparing round trip and one way trips -- can be visualized as follows:

![](./images/roundtrip-oneway.png)

Note that the durations of some round trip bike trips were in excess of 500 minutes.  For this comparison, it is more important to visualize the durations of shorter trips.  Therefore, the vertical range of durations was capped at 500 minutes.

Clearly, one way bike trips -- trips which could be associated with commuting -- are far shorter in time than are round trips.  Of note is the increase of one way trip durations shortly after 2 am and ending around 3:30 am.  It is possible that these trips coincide with the closing of bars in the Bay Area at 2 am.

##### Rider Membership

Rider membership comparisons between subscribers and customers was retrieved using the following query:

```
WITH temporal_category AS (
  SELECT
    EXTRACT(HOUR FROM start_date) AS hour,
    CAST(FLOOR(EXTRACT(MINUTE FROM start_date) / 15) * 15 AS INT64) AS quarter,
    EXTRACT(DAYOFWEEK FROM start_date) > 1 AND EXTRACT(DAYOFWEEK FROM start_date) < 7 AS weekday,
    subscriber_type
  FROM `bigquery-public-data.san_francisco.bikeshare_trips`
)
SELECT 
  TIME(hour, quarter, 0) AS start_time, 
  COUNT(hour) AS total_trips,
  subscriber_type
FROM temporal_category
WHERE weekday = TRUE
GROUP BY hour, quarter, subscriber_type
ORDER BY hour, quarter, subscriber_type DESC
```

The distribution of all bike trip frequencies across a 24-hour period -- comparing rider membership categories of "customers" and "subscribers" -- can be visualized as follows:

![](./images/customers-subscribers.png)

The bimodal distribution of subscribers' weekday bike trips across a 24-hour period is similar to that of the weekday to weekend ridership comparison.  Subscription bike trips dominate those purchased as customers, and are far more prevalent during the morning and evening commuting periods previously discussed.

##### "Commuting Trip" Criteria

Using the data retrieved and visualized above, the following criteria identifying a "commuting trip" can be defined as follows:

| Criteria | Value(s) |
| -------- | -------- |
| Time(s) of day | 7:30 - 9:30 am, 4:00 - 7:00 pm |
| Type | One-way |
| Duration | Not exceeding 30 minutes |
| Days of week | Monday - Friday (weekdays) |
| Rider membership | Subscribers |

#### Question 3

_What are current distributions of bike trips' lengths of time?  Would there be any incentive to offer specials to individuals in increments of time other than the all-day 30-minute increment?_

The data in "Duration of Trip" (above) is specific to bike trips occurring on weekdays; weekend days of Saturday and Sunday are excluded from the query and the visualization.  The query was modified slightly to **not** filter out Saturdays and Sundays:

```
WITH temporal_category AS (
  SELECT
    EXTRACT(HOUR FROM start_date) AS hour,
    CAST(FLOOR(EXTRACT(MINUTE FROM start_date) / 15) * 15 AS INT64) AS quarter,
    start_station_id != end_station_id AS one_way,
    duration_sec
  FROM `bigquery-public-data.san_francisco.bikeshare_trips`
)
SELECT 
  TIME(hour, quarter, 0) AS start_time, 
  COUNT(hour) AS total_trips,
  one_way,
  AVG(duration_sec) / 60 AS average_duration_minutes
FROM temporal_category
GROUP BY hour, quarter, one_way
ORDER BY hour, quarter, one_way DESC
```

The distribution of **all** average bike trip durations across a 24-hour time period -- comparing round trip and one way trips -- can be visualized as follows:

![](./images/allweek-roundtrip-oneway.png)

From the data previously observed, bike trip popularity appears to be concentrated during commute hours, one-way trips, and trips of durations less than 30 minutes.  It may not be in the business's best financial interest to incentivize bike trips solely upon their duration, but instead concentrate more upon where ridership appears to be the most popular: commuting.

#### Question 4

_How does ridership compare across the two memberships recorded with rides?  Is ridership changing over time (e.g. fewer rides among annual membership customers suggesting that the annual membership offer is lessening in popularity)?_

Data associated with members' participation in bike trips, comparing subscription members to customers, was retrieved with the following query:

```
WITH temporal_category AS (
  SELECT
    trip_id,
    EXTRACT(YEAR FROM start_date) AS year,
    EXTRACT(MONTH FROM start_date) AS month,
    subscriber_type,
    start_station_id != end_station_id AS one_way,
    duration_sec
  FROM `bigquery-public-data.san_francisco.bikeshare_trips`
)
SELECT 
  COUNT(trip_id) AS total_trips,
  month,
  year,
  FORMAT_DATE("%b-%Y", DATE(year, month, 1)) AS date,
  subscriber_type
FROM temporal_category
GROUP BY subscriber_type, year, month
ORDER BY subscriber_type, year, month
```

Visually, rider participation associated with types of membership over the course of operation is as follows:

![](./images/trips-by-membership.png)

Variance in total bike trips over time is substantially greater among riders with memberships than those without.  However, in both membership types' bike ride totals, patterns showing increased ridership in summer months (and decreased ridership in winter months) are apparent.

Trend lines suggest that ridership is increasing among those with subscriptions, and gradually decreasing among mere customers.  If we were to explore the potential of attempting to increase subscription members' participation, it might be helpful to perform the same query of data, but aggregate participation by city (i.e. _landmark_) or bike station.

#### Question 5

_How does ridership compare across stations associated with each "landmark" (e.g. "Redwood City", "Palo Alto")?_

The following query provides a distribution of the total number of bike trips within the cities (i.e. "landmarks") in which bike stations are located, totaled according to years for which data exists:

```
WITH landmark_category AS (
  SELECT
    t.trip_id AS trip_id,
    EXTRACT(DAYOFWEEK FROM t.start_date) > 1 AND EXTRACT(DAYOFWEEK FROM t.start_date) < 7 AS weekday,
    EXTRACT(YEAR FROM t.start_date) AS year,
    s.landmark AS landmark
  FROM `bigquery-public-data.san_francisco.bikeshare_trips` t
  INNER JOIN `bigquery-public-data.san_francisco.bikeshare_stations` s ON t.start_station_id = s.station_id
)
SELECT 
  COUNT(trip_id) AS total_trips,
  year,
  landmark
FROM landmark_category
WHERE weekday = TRUE
GROUP BY year, landmark
ORDER BY year ASC, landmark DESC
```

The distribution of bike trips' stations of origin can be visualized as follows:

![](./images/origin-city-by-year.png)

Clearly, San Francisco dominates bike trip totals.  This may partially be explained by the number of bike stations and bike docks within each city, retrieved with the following query:

```
SELECT landmark AS city, COUNT(station_id) AS total_stations, SUM(dockcount) AS bike_docks
FROM `bigquery-public-data.san_francisco.bikeshare_stations`
GROUP BY city
ORDER BY total_stations
```

|	city | total_stations | bike_docks |
| ---- | -------------- | ---------- |
| Palo Alto | 5 | 75 |
| Mountain View | 7 | 117 |
| Redwood City | 7 | 115 |
| San Jose | 18 | 302 |
| San Francisco | 37 | 735 |

Of note is decreased ridership recorded in years 2013 and 2016.  This is likely explained by the fact that ridership data for these years do not include all 12 months.  2013 data reflect only ridership between September and December, and 2016 data reflect only ridership between January and August.
