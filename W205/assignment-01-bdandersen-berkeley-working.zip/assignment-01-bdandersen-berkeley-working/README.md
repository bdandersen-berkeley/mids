# template-activity-01

## Assignment 01: Set up and prerequisites

1. Git
- Install git.
https://git-scm.com/downloads

- You may see references to the stand alone app for git on your desktop. That's not what we're using for this course.

- Watch the videos in this series that you need to watch (seriously, even if you've been working with git for a while, it's sometimes handy to revisit, e.g., the difference between git and Github). They are on youtube. If you don't have a subscription, it will pop up with short ads. Sorry, but these are really decent videos. There's about 30 min total.

https://www.youtube.com/playlist?list=PL5-da3qGB5IBLMp7LtN8Nc3Efd4hJq0kD

- Follow the instructions to do what the videos walk you through.



2. Data Engineering Jobs

- Google "data engineering jobs"
- Read ads (between 5&10)
- What are companies looking for in skills, experience, competencies?

---
I'll categorize jobs' suggested skills, experience and competencies as follows:

### Education

- Most require a **four-year degree in a technical field** as a minimum.
- Only one surveyed (Bayer) required a **graduate degree (preferring a Ph.D over a Master's)** as a minimum.
- Smaller organizations (e.g. startups) had no formal education requirements, but emphasized facility in the data domain, as well as experience.

### Programming Knowledge

- Most required programming experience with **higher-order languages**.  **Python** was frequently cited for its specificity in the data domain.  **JVM-founded languages** such as **Java, Scala and Groovy** were also popular.  Interestingly, few of the ten job descriptions I reviewed gave mention to **C or C++** and none mentioned **C#**.
- Like Python, for its specificity in the data domain, **R** was frequently cited.
- Many required **shell scripting languages** such as various **UNIX shells** or **Windows PowerShell**.

### Data Access Techniques

- All job descriptions listed facility with **SQL** as a requirement.
- Some descriptions specifically asked for experience with various RDBMS providers' **procedural query languages** such as **PL/SQL (Oracle)** and **T-SQL (Microsoft SQL Server, Sybase)**.
- Some descriptions also made reference to tools and means accommodating distributed data access such as **Hadoop, Spark and Kafka**.

### Cloud Hosting

- Most job descriptions required facility with cloud hosting services.  Among the three most popular cloud hosting providers, only one (**AWS**) was mentioned by name.  Neither **Google Cloud Platform** nor **Microsoft Azure** were mentioned.
- Some job descriptions made specific reference to AWS technologies such as **EC2, S3 and RedShift**.

### Various and Sundry Tools of the Trade

Scattered throughout job descriptions were a variety of tools of the data science trade including,

- Data analytics and visualization tools (e.g. **Tableau, D3**).
- Data modeling tools.
- Tools leveraged in the data pipeline and generally referred to as **ETL (extract/transform/load)** tools.

Here is just an edit associated with the commit from which I will be creating my first pull request for Assignment 01.
---

3. Submit a PR for this assignment.
- You changed this `README.md` in part 2;

- Commit your changes.

- Submit a PR with this `README.md` changed.
(following the instructions from the synchronous session)


4. You should know a few things about Markdown, the markup language that  determines how things look when you view them on the Github web interface. That is what we see when we review your work, so you should always check to see how your `README.me` file looks before you submit. You might check out [this cheat sheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) for some pointers.

Markdown is designed to look pretty much in plain text the way that you might guess it would look when made into pretty HTML.

### Here are some basics.

Use `#`, `##`, `###`, and so on to indicate headers. The header above is `###`.

```
Emphasis, aka italics, with *asterisks* or _underscores_.

Strong emphasis, aka bold, with **asterisks** or __underscores__.

Combined emphasis with **asterisks and _underscores_**.

Strikethrough uses two tildes. ~~Scratch this.~~

[This is a link](https://www.google.com)

```

Look like this:

Emphasis, aka italics, with *asterisks* or _underscores_.

Strong emphasis, aka bold, with **asterisks** or __underscores__.

Combined emphasis with **asterisks and _underscores_**.

Strikethrough uses two tildes. ~~Scratch this.~~

[This is a link](https://www.google.com)

#### Formatting Code

Since much of what we'll be doing is showing code and output, it's important to know how to display that such that it is readable.

    Inline `code` has `back-ticks around` it.

Inline `code` has `back-ticks around` it.


Blocks of code can be indicated by indenting with 4 spaces or with three back-ticks (<code>```</code).


    ```sql
    SELECT this, that, the_other
    FROM my_table
    ```

```sql
SELECT this, that, the_other
FROM my_table;
```

    ```
    col1               col2               col3
    fun                dog                cat
    mouse              rat                banana
    ```

```
col1               col2               col3
fun                dog                cat
mouse              rat                banana
```
without the backticks, that sql would look like:

SELECT this, that, the_other
FROM my_table;


and that pretty table would look like this (please don't do this!!):

col1               col2               col3
fun                dog                cat
mouse              rat                banana
